YASADA'S CONSTRUCTION — FREE WEBSITE FILES

QUICK PREVIEW
1. Extract this ZIP file.
2. Open the folder.
3. Double-click index.html to preview it in your browser.
   An internet connection is needed to load the sample Unsplash photos.

PUBLISH FOR FREE WITH GITHUB PAGES
1. Create/sign in to a GitHub account at https://github.com
2. Create a new public repository named: yasadas-construction
3. Upload index.html and this README (you may upload the ZIP contents; don't upload the ZIP as the only file).
4. In the repository, open Settings > Pages.
5. Under Build and deployment, choose "Deploy from a branch", branch "main", folder "/ (root)", then Save.
6. Wait for GitHub Pages to publish. Your free site URL will be similar to:
   https://YOUR-GITHUB-USERNAME.github.io/yasadas-construction/
   Replace YOUR-GITHUB-USERNAME with your actual GitHub username.

NOTES
- This is a static website, not a Wix site. It can be hosted free using GitHub Pages.
- The website has English, Telugu, and Hindi text options for the included content.
- Sample gallery photos are sourced from Unsplash URLs and are design inspiration only, not proof of your completed projects.
- No fake customer reviews are included.
- Verify the phone numbers and WhatsApp links before publishing.
- A custom domain is not required.
